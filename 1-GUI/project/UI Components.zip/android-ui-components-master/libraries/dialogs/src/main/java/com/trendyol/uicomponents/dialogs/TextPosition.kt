package com.trendyol.uicomponents.dialogs

enum class TextPosition {
    END, START, CENTER
}